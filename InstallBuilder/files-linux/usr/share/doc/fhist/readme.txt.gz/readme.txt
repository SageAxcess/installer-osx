ReadMe(FHist)                                                    ReadMe(FHist)



NNAAMMEE
       fhist - file history and comparison tools
       Copyright (C) 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999,
       2000, 2001, 2002, 2003, 2004, 2005, 2006, 2008, 2009 Peter Miller;

       Portions of this program are
       Copyright (C) 1990 David I. Bell.

       The _f_h_i_s_t package is distributed under the terms of the GNU General
       Public License, see the _L_I_C_E_N_S_E section, below, for more information.

DDEESSCCRRIIPPTTIIOONN
       The FHist package contains 3 utilities, a file history tool "_f_h_i_s_t", a
       file comparison tool "_f_c_o_m_p", and a file merging tool "_f_m_e_r_g_e".  All
       three are bundled together, because they all use the same minimal-
       difference algorithm.

       fhist
               Keeps track of versions of a file.  It works correctly when
               given binary files as input.  See _f_h_i_s_t(1) for more
               information.

       fcomp
               Compares two versions of a file, usually line-for-line textual
               comparison.  It is capable of comparing two binary files byte-
               for-byte.  See _f_c_o_m_p(1) for more information.

       fmerge
               Merges together edits from two descendants of a file.  See
               _f_m_e_r_g_e(1) for more information.

       The history tool presented here, fhist, is a _m_i_n_i_m_a_l history tool.  It
       provides no locking or branching.  This can be useful in contexts where
       the configuration management or change control be being provided by
       some other tool.

RREEFFEERREENNCCEESS
       This program is based on the algorithm in
              _A_n _O_(_N_D_) _D_i_f_f_e_r_e_n_c_e _A_l_g_o_r_i_t_h_m _a_n_d _I_t_s _V_a_r_i_a_t_i_o_n_s, Eugene W.
              Myers, TR 85-6, 10-April-1985, Department of Computer Science,
              The University of Arizona, Tuscon, Arizona 85721.
       See also:
              _A _F_i_l_e _C_o_m_p_a_r_i_s_o_n _P_r_o_g_r_a_m, Webb Miller and Eugene W. Myers,
              Software Practice and Experience, Volume 15, No. 11, November
              1985.

BBUUIILLDDIINNGG
       For complete instructions for host to build these programs, see the
       _B_U_I_L_D_I_N_G file included in this distribution.

AARRCCHHIIVVEE SSIITTEE
       The latest version of _f_h_i_s_t is available on the Web from:

                URL:    http://fhist.sourceforge.net/
                File:   index.html          # The FHist page.
                File:   fhist-1.18.README   # Description, from the tar file
                File:   fhist-1.18.lsm      # Description, in LSM format
                File:   fhist-1.18.spec     # RedHat package spec
                File:   fhist-1.18.tar.Z    # The complete source.
       FHist is also carried by sunsite.unc.edu in its Linux archives.  You
       will be able to find FHist on any of its mirrors.

                URL:    ftp://sunsite.unc.edu/pub/Linux/devel/vc/
                File:   fhist-1.18.README   # Description, from the tar file
                File:   fhist-1.18.lsm      # Description, in LSM format
                File:   fhist-1.18.spec     # RedHat package spec
                File:   fhist-1.18.tar.Z    # The complete source.
       This site is extensively mirrored around the world, so look for a copy
       near you (you will get much better response).

CCOOPPYYRRIIGGHHTT
       fhist version 1.18.D001
       Copyright (C) 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999,
       2000, 2001, 2002, 2003, 2004, 2005, 2006, 2008, 2009 Peter Miller;

       This program is derived from a work
       Copyright (C) 1990 David I. Bell.

       This program is free software; you can redistribute it and/or modify it
       under the terms of the GNU General Public License as published by the
       Free Software Foundation; either version 3 of the License, or (at your
       option) any later version.

       This program is distributed in the hope that it will be useful, but
       WITHOUT ANY WARRANTY; without even the implied warranty of
       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
       General Public License for more details.

       You should have received a copy of the GNU General Public License along
       with this program. If not, see <http://www.gnu.org/licenses/>.

AAUUTTHHOORRSS
       Peter Miller       Web:   http://miller.emu.id.au/pmiller/
       /\/\*           E-Mail:   pmiller@opensource.org.au

       David I. Bell      Web:   http://www.canb.auug.org.au/~dbell
                       E-Mail:   dbell@canb.auug.org.au

RREELLEEAASSEE NNOOTTEESS
       For excruciating detail, and also acknowledgements of those who
       generously sent me feedback, please see the _e_t_c_/_C_H_A_N_G_E_S_._1_._1_8 file
       included in this distribution.

       A number of features and bug fixes have been added to _f_h_i_s_t with this
       release.  A few of them are detailed here:

   VVeerrssiioonn 11..1188 ((1166--OOcctt--22000099))
       * The .XX macro usage has been made conditional in the man pages, to
       silence Debian lintian warnings.

       * The use of naked "-" have been replaced with "\-" for option
       introducers, "\[hy]" for hyphens, and "\[mi]" for minus signs, to
       silence Debian lintian warnings.

       * The author's email address has been updated.

   VVeerrssiioonn 11..1177 ((1177--JJuunn--22000088))
       * The licenseis now GPLv3.

       * The _f_h_i_s_t(1) command now accepts a remark string on the command line.

   VVeerrssiioonn 11..1166 ((2200--DDeecc--22000055))
       * There is a new _f_m_e_r_g_e _-_i_g_n_o_r_e_-_i_d_e_n_t_i_c_a_l_-_c_o_n_f_l_i_c_t_s option which may be
       used to suppress logical conflicts in which the same thing is done by
       both variants. This is often a better match for users' expectations for
       merging source code.

   VVeerrssiioonn 11..1155 ((88--NNoovv--22000055))
       * There is a new _f_c_o_m_p _-_n_o_-_b_i_n_a_r_y option, which may be used to prevent
       the comparison of binary files, instead it treats them both as empty.

       * A small build problem on MacOS X has been fixed.

   VVeerrssiioonn 11..1144 ((88--JJuunn--22000044))
       * The ./configure script now understands the --with-nlsdir option, so
       that you can place the .mo files.

       * The _f_h_i_s_t(1) program is now able to cope with numeric modules names.

       * The occasional false negative from test 26 has been fixed.  It was
       failing for some users because of message translation
       (internationalization) issues.

   VVeerrssiioonn 11..1133 ((1133--MMaarr--22000033))
       * A bug has been fixed in some of the tests.  They were susceptible to
       false negatives if the display width changed.

       * All references to the cuserid function have been replaced.  It isn't
       sufficiently portable to be used in real programs.

   VVeerrssiioonn 11..1122 ((2288--NNoovv--22000022))
       * Some build problems have been fixed.

   VVeerrssiioonn 11..1111 ((2266--NNoovv--22000022))
       * Some build problems, relating to modern ANSI C compilers choking on
       K&R function definitions with variable arguments, have been fixed.

       * Two bugs relating to the handling of binary files by _f_h_i_s_t(1) have
       been fixed.

       * A bug which left garbage files behind when a create failed has been
       fixed.

   VVeerrssiioonn 11..1100 ((99--JJuull--22000022))
       * Interrupt handling has been improved.

       * There is a new _f_h_i_s_t _-_N_o___K_e_y_w_o_r_d_s option, used to completely disable
       keyword substitution.

       * Several build problems have been fixed.

   VVeerrssiioonn 11..99 ((2233--OOcctt--22000011))
       No public release.

   VVeerrssiioonn 11..88 ((1166--OOcctt--22000011))
       * There is a new --BBIINNaarryy option for the _f_c_o_m_p(1) program, which
       compares binary files a byte at time, printing the results in
       hexadecimal.

       * The _f_c_o_m_p(1) program now silently copes with CRLF line terminations.

   VVeerrssiioonn 11..77 ((1111--AApprr--22000000))
       * The _f_h_i_s_t(1) command now has a --bbiinnaarryy option, which may be used to
       store the history of binary files.

       * The _f_h_i_s_t(1) command has a new --mmaakkee--ppaatthh option, which requests that
       the history directory be created if necessary.

       * A bug in _f_h_i_s_t(1) wich caused a SEGFAULT when you used the --tt option
       (extract to terminal) has been fixed.

   VVeerrssiioonn 11..66 ((2255--OOcctt--11999999))
       * An RPM spec file has been added to the distribution.

       * The code is now more robust about what various UNIX systems return
       from pathconf().

       * A bug with the "_f_c_o_m_p _-_b_l_a_n_k" option has been fixed.

   VVeerrssiioonn 11..55 ((11--JJuunn--11999999))
       * Binary files are now detected on input, and the utilities file
       gracefully with a warning or error message, as appropriate.

       * Some buffer over-run bugs have been fixed.

       * Several improvements have been made to the portability.

   VVeerrssiioonn 11..44 ((1166--SSeepp--11999988))
       * The install and build procedures have been made more robust, and they
       take note of more of the information provided by GNU Autoconf.

       * The error messages have been internationalized, so it is now possible
       to obtain error messages in your native language.  (If you would like
       to contribute with error message translations, please contact the
       author.)

       * An LSM description has been added, along with a HTML page to present
       it all nicely at the archive site.

       * A RedHat Package Manager spec file has been added, so that a RedHat
       package can be created.  The spec file is in the standard distribution.

   VVeerrssiioonn 11..33 ((2299--MMaarr--11999988))
       This version was not distributed  at all.

   VVeerrssiioonn 11..22
       This version was not distributed very widely.

       * The non-standard isblank function is no longer used, it cause too
       many portability problems.

       * The use of pathconf is not more robust for more operating systems.

   VVeerrssiioonn 11..11
       * The _f_h_i_s_t package now uses a shell script called _c_o_n_f_i_g_u_r_e to
       configure itself.  This script is generated using the _G_N_U _A_u_t_o_c_o_n_f
       utility.  This should make _f_h_i_s_t significantly easier to configure, and
       significantly more portable.

       * A bug has been fixed in the conflict reporting of the _f_m_e_r_g_e program.
       It now correctly opens the conflicts file.

       * The _f_h_i_s_t program now uses _p_a_t_h_c_o_n_f(2) to determine file name length
       limits.



Reference Manual                     FHist                       ReadMe(FHist)
